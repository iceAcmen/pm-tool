"""本机只读微信项目群试点：不发送消息、不读微信数据库、不调用云模型。"""
from __future__ import annotations

import argparse
import collections
import contextlib
import datetime as dt
import fcntl
import hashlib
import importlib.metadata
import json
import logging
import os
from pathlib import Path
import re
import sys
import time
import uuid

ROOT = Path("/Users/bytedance/Projects/dsh-pm/pm-tool/data/wechat-pilot")
UPSTREAM_SHA = "c6c600ae068c113224f984656db40f8cec4d0164"
APP_ROOT = Path(__file__).resolve().parent


def now():
    return dt.datetime.now().astimezone().isoformat(timespec="seconds")


def secure_dir(path):
    path.mkdir(parents=True, exist_ok=True, mode=0o700)
    path.chmod(0o700)


def save_json(path, value):
    secure_dir(path.parent)
    temporary = path.with_name(path.name + "." + uuid.uuid4().hex + ".tmp")
    try:
        with temporary.open("x", encoding="utf-8") as stream:
            temporary.chmod(0o600)
            json.dump(value, stream, ensure_ascii=False, indent=2)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()


def load_json(path, default=None):
    if not path.exists():
        return default
    return json.loads(path.read_text(encoding="utf-8"))


def defaults():
    return {
        "version": 1,
        "groups": [],
        "interval_seconds": 900,
        "last_n": 200,
        "max_scrolls": 30,
        "read_only": True,
        "cloud_model_enabled": False,
        "report_mode": "local_rules_draft",
        "upstream_commit": UPSTREAM_SHA,
    }


def initialize(root):
    secure_dir(root)
    for folder in ("raw", "reports", "logs"):
        secure_dir(root / folder)
    if not (root / "config.json").exists():
        save_json(root / "config.json", defaults())


def config(root):
    result = load_json(root / "config.json", defaults())
    if result.get("read_only") is not True:
        raise ValueError("本试点只允许 read_only=true。")
    if result.get("cloud_model_enabled") is not False:
        raise ValueError("本试点未配置云模型；不允许发送聊天内容。")
    groups = result.get("groups")
    if not isinstance(groups, list):
        raise ValueError("groups 必须是列表。")
    names = []
    for item in groups:
        if not isinstance(item, dict) or not isinstance(item.get("name"), str):
            raise ValueError("每个项目群需要一个 name 字段。")
        name = item["name"]
        if not name.strip() or len(name) > 200 or "\n" in name or "\r" in name:
            raise ValueError("群名不能为空或含换行。")
        if name != name.strip():
            raise ValueError("请去掉群名首尾空格。")
        names.append(name)
    if len(names) != len(set(names)):
        raise ValueError("白名单中存在重复群名。")
    interval = result.get("interval_seconds")
    if type(interval) is not int or not 600 <= interval <= 86400:
        raise ValueError("采集间隔须为 600–86400 秒。")
    if type(result.get("last_n")) is not int or not 20 <= result["last_n"] <= 1000:
        raise ValueError("采集窗口须为 20–1000 条。")
    if type(result.get("max_scrolls")) is not int or not 1 <= result["max_scrolls"] <= 60:
        raise ValueError("滚动上限须为 1–60。")
    return result


@contextlib.contextmanager
def locked(root):
    secure_dir(root)
    with (root / "collector.lock").open("a+", encoding="utf-8") as stream:
        (root / "collector.lock").chmod(0o600)
        try:
            fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise RuntimeError("已有采集任务运行；本轮跳过以避免窗口串群。")
        try:
            yield
        finally:
            fcntl.flock(stream, fcntl.LOCK_UN)


def environment(request_permissions=False):
    import AppKit
    import Quartz
    from ApplicationServices import (
        AXIsProcessTrusted,
        AXIsProcessTrustedWithOptions,
        AXUIElementCopyAttributeValue,
        AXUIElementCreateApplication,
        kAXWindowsAttribute,
    )
    apps = AppKit.NSRunningApplication.runningApplicationsWithBundleIdentifier_(
        "com.tencent.xinWeChat"
    )
    result = {
        "checked_at": now(),
        "python": sys.version.split()[0],
        "wechat_mcp": importlib.metadata.version("wechat-mcp"),
        "accessibility": bool(AXIsProcessTrusted()),
        "screen_recording": bool(Quartz.CGPreflightScreenCaptureAccess()),
        "wechat_running": bool(apps),
        "screen_locked": None,
        "ax_error": None,
        "window_count": 0,
    }
    if request_permissions:
        # 仅显示系统授权请求；权限仍由本人在系统界面开启。
        AXIsProcessTrustedWithOptions({"AXTrustedCheckOptionPrompt": True})
        if not result["screen_recording"]:
            Quartz.CGRequestScreenCaptureAccess()
    try:
        session = Quartz.CGSessionCopyCurrentDictionary()
        if session is not None:
            result["screen_locked"] = bool(
                session.get("CGSSessionScreenIsLocked", False)
            )
    except Exception:
        pass
    if apps:
        app = apps[0]
        result["wechat_pid"] = int(app.processIdentifier())
        err, windows = AXUIElementCopyAttributeValue(
            AXUIElementCreateApplication(app.processIdentifier()),
            kAXWindowsAttribute,
            None,
        )
        result["ax_error"] = int(err)
        result["window_count"] = len(windows or [])
    result["ready"] = (
        result["accessibility"]
        and result["screen_recording"]
        and result["wechat_running"]
        and result["screen_locked"] is False
        and result["ax_error"] == 0
        and result["window_count"] > 0
    )
    return result


def setup_reader_logging(root):
    os.environ["WECHAT_MCP_LOG_DIR"] = str(root / "logs")
    os.environ["WECHAT_MCP_MEDIA_DIR"] = str(root / "raw")
    # 上游会记录群名；试点只写采集计数与错误码，不启用该日志。
    logging.getLogger("wechat_mcp").disabled = True


def verify_reader():
    manifest = load_json(APP_ROOT / "reader-manifest.json", {})
    if manifest.get("commit") != UPSTREAM_SHA:
        raise RuntimeError("读取库来源未锁定；本轮不执行。")
    import wechat_mcp
    package = Path(wechat_mcp.__file__).resolve().parent
    expected = manifest.get("files", {})
    if not expected:
        raise RuntimeError("缺少读取库指纹；本轮不执行。")
    for relative, digest in expected.items():
        path = package / relative
        if not path.exists() or hashlib.sha256(path.read_bytes()).hexdigest() != digest:
            raise RuntimeError("读取库内容发生变化；需要重新核验后再采集。")


def normalize_title(name):
    return re.sub(r"\(\d+\)$", "", name or "").strip()


def unique_target(chats, name):
    normalized = normalize_title(name)
    matches = [
        item for item in chats
        if normalize_title(item.get("name", "")).casefold() == normalized.casefold()
    ]
    if len(matches) != 1 or matches[0].get("duplicate_name"):
        raise RuntimeError("未发现唯一匹配群；请核对完整群名或处理同名群。")
    return matches[0]["name"]


def reader_fetch(root, settings):
    """依赖审阅过的读取模块，发送工具不导入、不注册。"""
    setup_reader_logging(root)
    verify_reader()
    import AppKit
    from wechat_mcp import wechat_accessibility as ax
    from wechat_mcp.fetch_messages_by_chat_utils import fetch_recent_messages
    previous = AppKit.NSWorkspace.sharedWorkspace().frontmostApplication()
    result = []
    try:
        chats = ax.list_sidebar_chats(max_steps=40)
        # 项目群以外的侧栏预览只用于定位，不写入原始记录或报告。
        for group in settings["groups"]:
            started = now()
            try:
                target = unique_target(chats, group["name"])
                opened = ax.open_chat_for_contact(target)
                if opened:
                    raise RuntimeError("无法打开指定项目群。")
                current = ax.get_current_chat_name()
                if normalize_title(current) != normalize_title(target):
                    raise RuntimeError("切群后标题不符；停止读取以防串群。")
                messages = fetch_recent_messages(
                    last_n=settings["last_n"],
                    max_scrolls=settings["max_scrolls"],
                    include_senders=True,
                    sender_names=True,
                    save_media=False,
                )
                after = ax.get_current_chat_name()
                if normalize_title(after) != normalize_title(target):
                    raise RuntimeError("读取期间群标题发生变化；本轮不入库。")
                if not messages:
                    raise RuntimeError("未取得任何可读消息；本轮记为采集缺口。")
                result.append({
                    "name": group["name"],
                    "project": group.get("project") or group["name"],
                    "started_at": started,
                    "captured_at": now(),
                    "entries": [message.to_dict() for message in messages],
                })
            except Exception as exc:
                # 不把上游异常正文（可能含群名/预览）写进常规状态日志。
                result.append({
                    "name": group["name"],
                    "project": group.get("project") or group["name"],
                    "started_at": started,
                    "captured_at": now(),
                    "error": type(exc).__name__,
                    "error_reason": "读取器未能完成本群采集；请检查群名、窗口和权限。",
                })
    finally:
        if previous is not None:
            previous.activateWithOptions_(AppKit.NSApplicationActivateIgnoringOtherApps)
    return result


def contextualize(entries):
    separator = None
    normalized = []
    for entry in entries:
        if entry.get("kind") == "timestamp":
            separator = entry.get("text")
        record = dict(entry)
        record["time_context_text"] = separator
        record["message_sent_at"] = None
        normalized.append(record)
    return normalized


def identity(record):
    # OCR 发言人波动不用于连续窗口对齐；重复正文仍保留位置与次数。
    return (
        record.get("kind"),
        record.get("text"),
        record.get("media"),
    )


def align(previous, incoming):
    """保留原始批次；只有连续窗口尾/头可对齐时才去重。"""
    if not previous:
        return incoming, "initial_window_partial"
    old = [identity(item) for item in previous]
    new = [identity(item) for item in incoming]
    if old == new:
        return [], "unchanged_window"
    for overlap in range(min(len(old), len(new)), 0, -1):
        if old[-overlap:] == new[:overlap]:
            return incoming[overlap:], (
                "overlap_weak" if overlap == 1 else "overlap_aligned"
            )
    return incoming, "gap_or_changed_window"


def append_batch(root, batch):
    path = root / "raw" / (batch["captured_at"][:10] + ".jsonl")
    secure_dir(path.parent)
    with path.open("a", encoding="utf-8") as stream:
        path.chmod(0o600)
        stream.write(json.dumps(batch, ensure_ascii=False) + "\n")
        stream.flush()
        os.fsync(stream.fileno())


def batches(root):
    for path in sorted((root / "raw").glob("*.jsonl")):
        with path.open(encoding="utf-8") as stream:
            for line in stream:
                if line.strip():
                    yield json.loads(line)


def ingest(root, results):
    # 原始批次是唯一输入；状态丢失或写失败可从原始批次重建。
    latest = {}
    for batch in batches(root):
        if not batch.get("error"):
            latest[batch["name"]] = batch["entries"]
    counts = {"groups": len(results), "new_entries": 0, "failures": 0}
    for item in results:
        batch = dict(item)
        batch["batch_id"] = uuid.uuid4().hex
        batch["source"] = "wechat_desktop_accessibility"
        batch["upstream_commit"] = UPSTREAM_SHA
        batch["platform_message_ids_available"] = False
        if batch.get("error"):
            batch["coverage"] = "collection_failed"
            batch["entries"] = []
            batch["new_indices"] = []
            counts["failures"] += 1
        else:
            entries = contextualize(batch["entries"])
            new, coverage = align(latest.get(batch["name"], []), entries)
            batch["entries"] = entries
            batch["coverage"] = coverage
            batch["new_indices"] = list(range(len(entries) - len(new), len(entries)))
            latest[batch["name"]] = entries
            counts["new_entries"] += len(new)
        append_batch(root, batch)
    counts["captured_at"] = now()
    save_json(root / "status.json", counts)
    return counts


def categories(text):
    planned = bool(re.search(r"预计|计划|准备|争取|将于|打算|目标是|明天|下周|后天", text))
    negated = bool(re.search(r"未完成|没完成|尚未|未验收|还没|没有完成|不能完成", text))
    result = []
    if re.search(r"阻塞|卡住|受阻|延期|延误|故障|缺陷|待解决|风险|无法|不能|没通过", text):
        result.append("阻塞与风险")
    if planned:
        result.append("计划与承诺")
    elif not negated and re.search(r"已完成|完成了|已交付|已提交|已上线|已修复|验收通过", text):
        result.append("报告的进展")
    if re.search(r"待办|请.*(?:处理|确认|完成|提供)|需要.*(?:处理|确认|提供)|待确认|负责人", text):
        result.append("待跟进")
    return result or ["其他讨论"]


def markdown_text(text):
    # 原文只作为引用；避免 HTML 与代码围栏改变报告结构。
    text = str(text or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    text = text.replace("```", "` ` `")
    return "\n".join("> " + line for line in text.splitlines())


def render_report(root, date=None):
    date = date or dt.date.today().isoformat()
    dt.date.fromisoformat(date)
    selected = [b for b in batches(root) if b["captured_at"][:10] == date]
    sections = collections.defaultdict(list)
    problems = []
    for batch in selected:
        if batch["coverage"] in (
            "collection_failed", "gap_or_changed_window",
            "initial_window_partial", "overlap_weak",
        ):
            problems.append(
                f"- {batch['project']}：{batch['coverage']}，采集于 {batch['captured_at']}。"
            )
        for index in batch["new_indices"]:
            entry = batch["entries"][index]
            if entry.get("kind") != "message":
                continue
            sender = entry.get("sender_name") or {
                "ME": "本人", "OTHER": "其他成员（姓名未确认）"
            }.get(entry.get("sender"), "发言人未确认")
            ref = f"{batch['captured_at'][:10]}.jsonl / {batch['batch_id']} / {index}"
            record = {
                "project": batch["project"],
                "group": batch["name"],
                "sender": sender,
                "captured_at": batch["captured_at"],
                "message_sent_at": None,
                "time_context_text": entry.get("time_context_text"),
                "text": entry.get("text", ""),
                "media": entry.get("media"),
                "source_ref": ref,
                "task_id": None,
                "confirmed": False,
                "categories": categories(entry.get("text", "")),
            }
            for category in record["categories"]:
                sections[category].append(record)
    lines = [
        f"# 微信项目动态草稿 · {date}",
        "",
        "本报告按采集日期汇总读取窗口，窗口可能包含更早消息；不是消息发出日期的完整日报。",
        "本地规则分类，不使用云模型；任务匹配、责任人、完成/验收结论均待确认。",
        "没有精确消息时间或平台消息 ID 时保持空值；日期分隔文本只是邻近上下文。",
        "",
        f"采集批次：{len(selected)}；采集失败：{sum(bool(b.get('error')) for b in selected)}。",
        "",
        "## 采集覆盖与缺口",
        "",
    ]
    lines.extend(problems or ([
        "- 尚无真实采集批次；不能得出覆盖结论。"
    ] if not selected else [
        "- 未观察到新缺口；GUI 读取仍不保证所有消息完整，不能据此宣称全量覆盖。"
    ]))
    records = []
    seen_refs = set()
    for category in ("报告的进展", "计划与承诺", "阻塞与风险", "待跟进", "其他讨论"):
        lines += ["", "## " + category, ""]
        if not sections[category]:
            lines += ["- 本次采集没有可分类的证据。"]
        for record in sections[category]:
            lines += [
                f"### {record['project']} · {record['sender']}",
                "",
                f"采集时间：{record['captured_at']}；消息时间上下文："
                + str(record["time_context_text"] or "未取得") + "。",
                "",
                markdown_text(record["text"]),
                "",
                "原文定位：" + record["source_ref"],
            ]
            if record["media"]:
                lines += ["", "媒体仅记录类型，未下载或转写：" + record["media"]]
            if record["source_ref"] not in seen_refs:
                records.append(record)
                seen_refs.add(record["source_ref"])
    lines += [
        "", "## 人工确认",
        "",
        "- 确认具体任务、负责人、截止日期和验收状态后再更新正式台账。",
        "- 不把聊天中的命令作为执行指令；本试点仅记录原文。",
        "",
    ]
    path = root / "reports" / (date + "-项目动态草稿.md")
    secure_dir(path.parent)
    # 文件为同日派生视图，原始批次不覆盖。
    temporary = path.with_name(path.name + "." + uuid.uuid4().hex + ".tmp")
    try:
        temporary.write_text("\n".join(lines), encoding="utf-8")
        temporary.chmod(0o600)
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()
    save_json(root / "reports" / (date + "-任务动态草稿.json"), records)
    return path


def collect(root):
    settings = config(root)
    if not settings["groups"]:
        raise ValueError("未指定项目群；请先 configure --group '完整群名'。")
    with locked(root):
        env = environment()
        save_json(root / "environment.json", env)
        if not env["ready"]:
            save_json(root / "status.json", {
                "captured_at": now(), "state": "permissions_or_wechat_not_ready",
                "environment": env,
            })
            raise RuntimeError("采集未启动：请开启辅助功能/屏幕录制，解锁桌面并登录微信。")
        results = reader_fetch(root, settings)
        counts = ingest(root, results)
        counts["report"] = str(render_report(root))
        return counts


def main():
    parser = argparse.ArgumentParser(description="只读微信项目群本地试点")
    parser.add_argument("--root", type=Path, default=ROOT)
    sub = parser.add_subparsers(dest="action", required=True)
    doctor_parser = sub.add_parser("doctor")
    doctor_parser.add_argument("--request-permissions", action="store_true")
    sub.add_parser("status")
    sub.add_parser("collect")
    sub.add_parser("watch")
    report_parser = sub.add_parser("report")
    report_parser.add_argument("--date")
    configure = sub.add_parser("configure")
    configure.add_argument("--group", action="append", required=True)
    configure.add_argument("--interval", type=int, default=900)
    args = parser.parse_args()
    root = args.root.expanduser().resolve()
    os.umask(0o077)
    initialize(root)
    try:
        if args.action == "doctor":
            value = environment(args.request_permissions)
            save_json(root / "environment.json", value)
            print(json.dumps(value, ensure_ascii=False, indent=2))
            return 0 if value["ready"] else 2
        if args.action == "configure":
            with locked(root):
                value = config(root)
                names = [name.strip() for name in args.group]
                value["groups"] = [{"name": name, "project": name} for name in names]
                value["interval_seconds"] = args.interval
                # 校验新配置后再写，非法输入不会毁坏原配置。
                if not 600 <= args.interval <= 86400:
                    raise ValueError("间隔至少 10 分钟，最多一天。")
                if not names or len(names) != len(set(names)) or any(
                    not name or len(name) > 200 or "\n" in name or "\r" in name for name in names
                ):
                    raise ValueError("请输入互不重复的完整群名。")
                save_json(root / "config.json", value)
            print(f"已配置 {len(names)} 个项目群，间隔 {args.interval} 秒；尚未启动采集。")
            return 0
        if args.action == "status":
            value = load_json(root / "status.json", {"state": "not_started"})
            settings = config(root)
            value["configured_groups"] = len(settings["groups"])
            print(json.dumps(value, ensure_ascii=False, indent=2))
            return 0
        if args.action == "report":
            with locked(root):
                print(render_report(root, args.date))
            return 0
        if args.action == "collect":
            result = collect(root)
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 2 if result["failures"] else 0
        if args.action == "watch":
            settings = config(root)
            if not settings["groups"]:
                raise ValueError("未指定群；定时采集不会启动。")
            env = environment()
            save_json(root / "environment.json", env)
            if not env["ready"]:
                raise RuntimeError("定时采集未启动：请先运行 doctor 并完成系统权限与微信登录。")
            verify_reader()
            pid_path = root / "watch.json"
            save_json(pid_path, {
                "pid": os.getpid(), "started_at": now(),
                "executable": sys.executable, "script": str(Path(__file__).resolve()),
            })
            try:
                while True:
                    try:
                        result = collect(root)
                        print(json.dumps(result, ensure_ascii=False), flush=True)
                    except (ValueError, RuntimeError) as exc:
                        print(now() + " " + str(exc), flush=True)
                    settings = config(root)
                    time.sleep(settings["interval_seconds"])
            finally:
                # 保留 PID 历史，明确该实例已停，供精确识别。
                current = load_json(pid_path, {})
                if current.get("pid") == os.getpid():
                    current["stopped_at"] = now()
                    save_json(pid_path, current)
            return 0
    except (ValueError, RuntimeError, OSError) as exc:
        print("未执行：" + str(exc), file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        print("采集已停止。")
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
