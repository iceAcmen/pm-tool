#!/bin/bash
set -eu
PYTHON="/Users/bytedance/.local/share/wechat-project-pilot/venv/bin/python"
SCRIPT="/Users/bytedance/.local/share/wechat-project-pilot/app/pilot.py"
if [ "$#" -gt 0 ]; then
  exec "$PYTHON" "$SCRIPT" "$@"
fi
echo "微信项目群只读采集试点"
echo "先检查辅助功能、屏幕录制和微信运行状态。"
if "$PYTHON" "$SCRIPT" doctor --request-permissions; then
  echo "权限已就绪。请在此终端配置项目群后运行 collect 或 watch。"
else
  echo "请在系统设置中为 Terminal（终端）开启辅助功能和屏幕录制。"
  echo "随后重新打开终端，再运行本入口检查。"
fi
echo "按回车关闭此窗口。"
read -r _
