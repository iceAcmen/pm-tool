"""WeChat MCP server package."""
