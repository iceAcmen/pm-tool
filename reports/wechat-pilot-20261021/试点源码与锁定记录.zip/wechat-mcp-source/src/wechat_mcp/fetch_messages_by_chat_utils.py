from __future__ import annotations

import os
import time
from collections import Counter
from dataclasses import asdict, dataclass
from difflib import SequenceMatcher
from pathlib import Path
from typing import Any, Literal

import Quartz
from ApplicationServices import (
    AXUIElementCopyMultipleAttributeValues,
    kAXChildrenAttribute,
    kAXIdentifierAttribute,
    kAXListRole,
    kAXPositionAttribute,
    kAXSizeAttribute,
    kAXTitleAttribute,
    kAXValueAttribute,
)
from PIL import Image, ImageChops

from .logging_config import logger
from .wechat_accessibility import (
    ax_get,
    axvalue_to_point,
    axvalue_to_size,
    dfs,
    get_list_center,
    get_wechat_ax_app,
    post_scroll_pixels,
)

# Identifiers WeChat 4.x uses inside the conversation pane.
MESSAGE_LIST_IDENTIFIER = "chat_message_list"
MESSAGE_BUBBLE_IDENTIFIER = "chat_bubble_item_view"
VIRTUAL_CELL_IDENTIFIER = "virtual_cell"

# Rows carrying one of these placeholders are attachments, not text.
MEDIA_PLACEHOLDERS: dict[str, str] = {
    "Image": "image",
    "Photo": "image",
    "图片": "image",
    "Video": "video",
    "视频": "video",
    "Sticker": "sticker",
    "表情": "sticker",
    "动画表情": "sticker",
    "Voice message": "voice",
    "Voice Message": "voice",
    "语音": "voice",
    "File": "file",
    "文件": "file",
    "Location": "location",
    "位置": "location",
    "Link": "link",
    "链接": "link",
    "Transfer": "transfer",
    "转账": "transfer",
    "Red": "red_packet",
    "红包": "red_packet",
    "Contact": "contact_card",
    "名片": "contact_card",
    "Music": "music",
    "音乐": "music",
}

# Attachments worth saving a picture of: ones whose content cannot be
# read from the AX tree at all.
VISUAL_MEDIA = {"image", "video", "sticker"}

# Fraction of the viewport advanced per scroll step; the remainder is the
# overlap that lets consecutive reads be stitched together.
MESSAGE_SCROLL_FRACTION = 0.70
MESSAGE_JUMP_PIXELS = 40000
# A ceiling, not a sleep: _wait_for_rows returns the moment the rows
# change, so a generous value costs nothing on a productive scroll and
# only applies when the view genuinely isn't moving. At 0.4s this cut
# productive scrolls short and silently returned 25 messages of 40.
SCROLL_SETTLE_TIMEOUT = 0.80

# How different the two margins must be before a bubble counts as
# left- or right-anchored.
SENDER_DEADBAND_PIXELS = 10

# Width of the scrollbar gutter at the right edge of the message pane.
# The scrollbar is only drawn while the list is scrolling, so it pins the
# right margin to zero for some captures and not others — which read as
# "right-anchored" and flipped incoming messages to ME.
SCROLLBAR_GUTTER_PIXELS = 28

MessageKind = Literal["message", "timestamp", "system"]
SenderLabel = Literal["ME", "OTHER", "UNKNOWN"]

_ROW_ATTRS = [
    kAXIdentifierAttribute,
    kAXTitleAttribute,
    kAXValueAttribute,
    kAXPositionAttribute,
    kAXSizeAttribute,
]


def screen_capture_available() -> bool:
    """
    Whether macOS will actually let us capture WeChat's window.

    Without Screen Recording permission, captures silently come back as
    the desktop wallpaper with every window omitted, so pixel analysis
    produces confident nonsense. Checking up front lets us say so
    instead of guessing.
    """
    try:
        return bool(Quartz.CGPreflightScreenCaptureAccess())
    except Exception:  # pragma: no cover - depends on OS version
        return False


def capture_rect(
    left: float, top: float, width: float, height: float, retina: bool = False
) -> Image.Image | None:
    """
    Capture a screen region via CoreGraphics.

    This is markedly cheaper than PIL's ImageGrab (which shells out to
    /usr/sbin/screencapture): ~18ms at 1x and ~40ms at Retina, versus
    ~125ms. Sender alignment only needs 1x; Retina is reserved for
    attachments we actually want to look at.
    """
    if width <= 0 or height <= 0:
        return None

    options = Quartz.kCGWindowImageBoundsIgnoreFraming
    if not retina:
        options |= Quartz.kCGWindowImageNominalResolution

    cg_image = Quartz.CGWindowListCreateImage(
        Quartz.CGRectMake(left, top, width, height),
        Quartz.kCGWindowListOptionOnScreenOnly,
        Quartz.kCGNullWindowID,
        options,
    )
    if cg_image is None:
        return None

    provider = Quartz.CGImageGetDataProvider(cg_image)
    data = Quartz.CGDataProviderCopyData(provider)
    if data is None:
        return None

    return Image.frombuffer(
        "RGBA",
        (Quartz.CGImageGetWidth(cg_image), Quartz.CGImageGetHeight(cg_image)),
        data,
        "raw",
        "BGRA",
        Quartz.CGImageGetBytesPerRow(cg_image),
        1,
    ).convert("RGB")


def get_messages_list(ax_app: Any) -> Any:
    """
    Find the AX list holding chat messages in the current WeChat window.

    Matched on the stable identifier first; the window title is only a
    fallback, since it is localized.
    """

    def by_identifier(el, role, title, identifier):
        return role == kAXListRole and identifier == MESSAGE_LIST_IDENTIFIER

    msg_list = dfs(ax_app, by_identifier)
    if msg_list is not None:
        return msg_list

    def by_title(el, role, title, identifier):
        return role == kAXListRole and (title or "") == "Messages"

    msg_list = dfs(ax_app, by_title)
    if msg_list is None:
        raise RuntimeError("Could not find WeChat's message list in the AX tree")
    return msg_list


@dataclass
class MessageRow:
    """One rendered row of the conversation, before sender attribution."""

    element: Any
    text: str
    kind: MessageKind
    media: str | None
    y: float
    height: float


def _detect_media(text: str) -> str | None:
    """
    Identify an attachment from its placeholder text.

    Placeholders are not always bare words: a video reads "Video 0:05",
    and a file carries its name and size on following lines, so match on
    the first line and then its first word.
    """
    first_line = text.split("\n", 1)[0].strip()
    if first_line in MEDIA_PLACEHOLDERS:
        return MEDIA_PLACEHOLDERS[first_line]

    words = first_line.split()
    if words:
        return MEDIA_PLACEHOLDERS.get(words[0])
    return None


def _looks_like_timestamp(text: str) -> bool:
    """Date/time separators are short and mostly digits."""
    if len(text) > 24:
        return False
    digits = sum(char.isdigit() for char in text)
    return digits >= 3 and digits >= len(text.replace(" ", "")) / 3


def _read_row(element) -> MessageRow | None:
    """Read one row of the message list, or None if it is not a real row."""
    err, values = AXUIElementCopyMultipleAttributeValues(element, _ROW_ATTRS, 0, None)
    if err != 0 or values is None or len(values) < 5:
        return None

    identifier, title, value, pos_ref, size_ref = values[:5]

    # Recycled placeholders for rows that are not currently rendered.
    if identifier == VIRTUAL_CELL_IDENTIFIER:
        return None

    text = title if isinstance(title, str) and title else value
    if not isinstance(text, str) or not text.strip():
        return None

    size = axvalue_to_size(size_ref)
    point = axvalue_to_point(pos_ref)
    if size is None or point is None or size[1] <= 0:
        return None

    text = text.strip()
    if identifier == MESSAGE_BUBBLE_IDENTIFIER:
        kind: MessageKind = "message"
        media = _detect_media(text)
    else:
        # Rows without the bubble identifier are date separators and
        # system notices ("You've added X."), not messages anyone sent.
        kind = "timestamp" if _looks_like_timestamp(text) else "system"
        media = None

    return MessageRow(
        element=element,
        text=text,
        kind=kind,
        media=media,
        y=point[1],
        height=size[1],
    )


def collect_visible_rows(msg_list: Any) -> list[MessageRow]:
    """Read the conversation rows currently rendered, oldest first."""
    rows: list[MessageRow] = []
    for child in ax_get(msg_list, kAXChildrenAttribute) or []:
        row = _read_row(child)
        if row is not None:
            rows.append(row)
    rows.sort(key=lambda row: row.y)
    return rows


def _rows_fingerprint(rows: list[MessageRow]) -> str:
    return "|".join(f"{row.y:.0f}:{row.text}" for row in rows)


def _background_colour(image: Image.Image) -> tuple[int, int, int]:
    """The most common colour in a region: its background."""
    sample = image.resize((max(1, image.width // 8), max(1, image.height // 8)))
    return Counter(sample.getdata()).most_common(1)[0][0]


def _content_span(crop: Image.Image, background, threshold: int = 40):
    """
    Horizontal span of non-background content within a row.

    Uses PIL's C-level difference/getbbox on a downscaled copy rather
    than a Python pixel loop. Comparing against the row's own background
    also makes this work in light and dark themes alike, unlike the
    absolute brightness test it replaces.
    """
    if crop.width < 8 or crop.height < 4:
        return None

    factor = 4
    small = crop.resize((max(1, crop.width // factor), max(1, crop.height // factor)))
    diff = ImageChops.difference(small, Image.new("RGB", small.size, background))
    mask = diff.convert("L").point(lambda v: 255 if v > threshold else 0)
    box = mask.getbbox()
    if box is None:
        return None
    return box[0] * factor, box[2] * factor


def classify_row_sender(
    image: Image.Image | None, origin, scale: float, row: MessageRow
) -> tuple[SenderLabel, tuple[int, int, int, int] | None]:
    """
    Decide whether a row was sent by us or by the other party, and return
    the box of its drawn content.

    WeChat right-aligns your own messages and left-aligns everyone
    else's, but the AX row spans the full pane width either way, so the
    alignment can only be read from pixels.
    """
    if image is None:
        return "UNKNOWN", None

    top = max(0, min(int((row.y - origin[1]) * scale), image.height))
    bottom = max(0, min(int(top + row.height * scale), image.height))
    if bottom - top < 4:
        return "UNKNOWN", None

    usable_width = max(1, image.width - SCROLLBAR_GUTTER_PIXELS)
    crop = image.crop((0, top, usable_width, bottom))
    span = _content_span(crop, _background_colour(crop))
    if span is None:
        return "UNKNOWN", None

    left, right = span

    # A bubble is anchored to one margin: its own avatar sits at the left
    # edge for incoming messages and the right edge for outgoing ones.
    # Comparing the two gaps classifies wide bubbles that straddle the
    # centre, which a midpoint test cannot.
    left_gap = left
    right_gap = usable_width - right
    # A small absolute deadband, not a fraction of the pane: the avatar
    # pins one margin at ~20px, so a wide bubble can leave the other gap
    # only slightly larger and still be perfectly unambiguous. A 4%-of-
    # width deadband swallowed exactly those long messages as UNKNOWN.
    if abs(left_gap - right_gap) < SENDER_DEADBAND_PIXELS:
        sender: SenderLabel = "UNKNOWN"
    elif left_gap < right_gap:
        sender = "OTHER"
    else:
        sender = "ME"

    return sender, (left, top, right, bottom)


# Height of the strip above a group-chat bubble that holds the sender's
# display name, in points.
NAME_BAND_POINTS = 24
MAX_SENDER_NAME_CHARS = 40
# Similarity above which two OCR'd names are treated as the same person.
NAME_MATCH_RATIO = 0.75


def _pil_to_cgimage(image: Image.Image):
    """Hand a PIL image to Vision without going through the filesystem."""
    import io

    buffer = io.BytesIO()
    image.save(buffer, "PNG")
    payload = buffer.getvalue()
    data = Quartz.CFDataCreate(None, payload, len(payload))
    source = Quartz.CGImageSourceCreateWithData(data, None)
    if source is None:
        return None
    return Quartz.CGImageSourceCreateImageAtIndex(source, 0, None)


def _ocr_lines(image: Image.Image) -> list[tuple[str, float]]:
    """
    Run macOS' built-in text recognition, returning (text, y) pairs with y
    in image pixels from the top.
    """
    try:
        import Vision
    except ImportError:  # pragma: no cover - Vision ships with macOS
        return []

    cg_image = _pil_to_cgimage(image)
    if cg_image is None:
        return []

    captured: dict[str, Any] = {}

    def completion(request, error):
        captured["observations"] = request.results()

    request = Vision.VNRecognizeTextRequest.alloc().initWithCompletionHandler_(
        completion
    )
    request.setRecognitionLevel_(0)  # accurate; names are small text
    request.setUsesLanguageCorrection_(False)
    # Chinese must come first: with "en-US" leading, Vision mangles
    # Chinese names into lookalike Latin letters ("王涵正" -> "EiE") and
    # is slower doing it.
    request.setRecognitionLanguages_(["zh-Hans", "en-US"])

    handler = Vision.VNImageRequestHandler.alloc().initWithCGImage_options_(
        cg_image, None
    )
    handler.performRequests_error_([request], None)

    lines: list[tuple[str, float]] = []
    for observation in captured.get("observations") or []:
        candidates = observation.topCandidates_(1)
        if not candidates:
            continue
        box = observation.boundingBox()
        # Vision's origin is bottom-left; convert to top-down pixels.
        y = (1 - box.origin.y - box.size.height) * image.height
        lines.append((str(candidates[0].string()), y))
    return lines


def read_sender_names(origin, size, rows: list[MessageRow]) -> dict[int, str]:
    """
    Read the display name WeChat draws above each group-chat bubble.

    The names are rendered text with no AX representation, so they can
    only be recovered by recognising them. To keep that affordable, the
    thin name strips are stitched into one small sheet and recognised in
    a single pass instead of OCR'ing the whole conversation pane.
    """
    image = capture_rect(origin[0], origin[1], size[0], size[1], retina=True)
    if image is None:
        return {}

    scale = image.width / size[0] if size[0] else 1.0
    band_height = max(1, int(NAME_BAND_POINTS * scale))

    bands: list[tuple[int, Image.Image]] = []
    for index, row in enumerate(rows):
        if row.kind != "message":
            continue
        top = int((row.y - origin[1]) * scale)
        if top < 0 or top + band_height > image.height:
            continue
        bands.append((index, image.crop((0, top, image.width, top + band_height))))

    if not bands:
        return {}

    sheet = Image.new(
        "RGB", (image.width, band_height * len(bands)), (255, 255, 255)
    )
    for position, (_, band) in enumerate(bands):
        sheet.paste(band, (0, position * band_height))

    names: dict[int, str] = {}
    for text, y in _ocr_lines(sheet):
        position = int(y // band_height)
        if not 0 <= position < len(bands):
            continue
        row_index = bands[position][0]
        cleaned = text.strip()
        # A name is short; anything longer is bubble text bleeding in,
        # which is what 1:1 chats (no name line) would produce.
        if cleaned and len(cleaned) <= MAX_SENDER_NAME_CHARS:
            names.setdefault(row_index, cleaned)

    return _canonicalize_names(names)


def _canonicalize_names(names: dict[int, str]) -> dict[int, str]:
    """
    Collapse OCR variants of the same person onto one spelling.

    The same few people recur throughout a chat, so a misread ("Rvan Wong
    王涵正" for "Ryan Wong 王涵正") is nearly always outnumbered by
    correct readings of the same name. Snap each name to the most common
    near-match rather than letting one bad frame invent a new person.
    """
    if not names:
        return names

    counts = Counter(names.values())
    canonical: dict[str, str] = {}
    # Most frequent first, so rarer variants snap onto commoner ones.
    ranked = [name for name, _ in counts.most_common()]

    for name in ranked:
        best = name
        for candidate in ranked:
            if candidate == name or counts[candidate] <= counts[name]:
                continue
            if SequenceMatcher(None, name, candidate).ratio() >= NAME_MATCH_RATIO:
                best = canonical.get(candidate, candidate)
                break
        canonical[name] = best

    return {index: canonical.get(name, name) for index, name in names.items()}


@dataclass
class ChatMessage:
    sender: SenderLabel
    text: str
    kind: MessageKind = "message"
    media: str | None = None
    image_path: str | None = None
    sender_name: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def identity(self) -> tuple[str, str, str | None]:
        """Value used to align overlapping reads."""
        return self.kind, self.text, self.media


def _media_dir() -> Path:
    directory = Path(
        os.getenv("WECHAT_MCP_MEDIA_DIR", Path.home() / "logs" / "wechat_media")
    ).expanduser()
    directory.mkdir(parents=True, exist_ok=True)
    return directory


def _save_media(row: MessageRow, origin, box, index: int) -> str | None:
    """
    Save a picture of an attachment, captured fresh at Retina resolution.

    Only attachments are captured this way — ordinary text messages are
    never written to disk, and this second capture happens only when a
    row actually holds something unreadable from the AX tree.
    """
    if box is None:
        return None

    left, _, right, _ = box
    width = right - left
    if width < 24 or row.height < 24:
        return None

    image = capture_rect(origin[0] + left, row.y, width, row.height, retina=True)
    if image is None:
        return None

    try:
        path = _media_dir() / f"wechat_{int(time.time())}_{index}.png"
        image.save(path)
        return str(path)
    except Exception as exc:  # pragma: no cover - disk/permission issues
        logger.warning("Could not save message media: %s", exc)
        return None


def _merge_older(
    known: list[ChatMessage], revealed: list[ChatMessage]
) -> list[ChatMessage]:
    """
    Prepend newly revealed older messages to what we already have.

    Consecutive reads overlap, so the tail of `revealed` should match the
    head of `known`. Aligning on the longest such run is robust to
    repeated message texts, which a single-anchor search is not — and
    repeated texts really do occur ("我是X I'm X." twice in a row).
    """
    if not known:
        return list(revealed)
    if not revealed:
        return known

    known_ids = [m.identity() for m in known]
    revealed_ids = [m.identity() for m in revealed]

    for overlap in range(min(len(known_ids), len(revealed_ids)), 0, -1):
        if revealed_ids[-overlap:] == known_ids[:overlap]:
            return revealed[:-overlap] + known

    # No overlap: the step outran the viewport. Keep both halves rather
    # than silently dropping history.
    return revealed + known


def _wait_for_rows(
    msg_list: Any, previous: str, timeout: float = SCROLL_SETTLE_TIMEOUT
) -> list[MessageRow]:
    """
    Poll until the rendered rows change after a scroll, instead of
    sleeping a fixed interval. Returns as soon as the view has moved.
    """
    deadline = time.time() + timeout
    rows = collect_visible_rows(msg_list)
    while time.time() < deadline and _rows_fingerprint(rows) == previous:
        time.sleep(0.02)
        rows = collect_visible_rows(msg_list)

    # The rows have started moving; now let them come to rest. Returning
    # on first change hands back coordinates from the middle of a scroll
    # animation, which then no longer match a screenshot taken a moment
    # later — that misaligned the sender crop by a whole row.
    fingerprint = _rows_fingerprint(rows)
    while time.time() < deadline:
        time.sleep(0.03)
        settled = collect_visible_rows(msg_list)
        settled_fingerprint = _rows_fingerprint(settled)
        if settled_fingerprint == fingerprint:
            return settled
        rows, fingerprint = settled, settled_fingerprint
    return rows


def _capture_aligned(msg_list: Any, origin, size):
    """
    Capture the message pane together with row geometry that provably
    matches it.

    Row coordinates and the screenshot are read through different APIs at
    different instants. If the list moves in between, every crop is offset
    and senders get attributed to the neighbouring message. Reading the
    rows either side of the capture and requiring them to be identical
    rules that out.
    """
    image = None
    rows = collect_visible_rows(msg_list)
    for _ in range(3):
        before = _rows_fingerprint(rows)
        image = capture_rect(origin[0], origin[1], size[0], size[1])
        rows = collect_visible_rows(msg_list)
        if _rows_fingerprint(rows) == before:
            return image, rows
        time.sleep(0.05)

    logger.warning("Message list kept moving during capture; senders may be unreliable")
    return image, rows


def scroll_to_latest(msg_list: Any, center: tuple[float, float]) -> None:
    """Jump to the newest messages at the bottom of the conversation."""
    post_scroll_pixels(center, -MESSAGE_JUMP_PIXELS)
    time.sleep(0.2)


def fetch_recent_messages(
    last_n: int = 100,
    max_scrolls: int | None = None,
    include_senders: bool = True,
    save_media: bool = True,
    sender_names: bool = False,
) -> list[ChatMessage]:
    """
    Fetch the last N entries of the currently open chat, scrolling back
    through history as needed.

    Each entry carries a `kind`: "message" for something someone sent,
    "timestamp" for a date separator, "system" for notices such as
    "You've added X.". Attachments carry a `media` type ("image",
    "video", ...) and, for visual ones, an `image_path` pointing at a PNG
    of just that attachment.

    Sender attribution reads which side of the pane a bubble is drawn on,
    since WeChat exposes no sender in the AX tree. That needs one
    lightweight 1x screen capture per scrolled screenful (~18ms, held in
    memory only). Pass include_senders=False to skip capturing entirely;
    pass save_media=False to keep attachment pictures off disk.
    """
    ax_app = get_wechat_ax_app()
    msg_list = get_messages_list(ax_app)
    center = get_list_center(msg_list)

    origin = axvalue_to_point(ax_get(msg_list, kAXPositionAttribute))
    size = axvalue_to_size(ax_get(msg_list, kAXSizeAttribute))
    if origin is None or size is None:
        raise RuntimeError("Failed to get bounds for WeChat's message list")

    can_capture = include_senders and screen_capture_available()
    if include_senders and not can_capture:
        logger.warning(
            "Screen Recording permission is not granted: senders will be "
            "UNKNOWN and attachments will not be saved. Grant it in System "
            "Settings > Privacy & Security > Screen & System Audio Recording."
        )

    scroll_to_latest(msg_list, center)

    messages: list[ChatMessage] = []
    rows = collect_visible_rows(msg_list)
    scrolls = 0
    no_new = 0
    media_index = 0

    while True:
        if not rows:
            break

        # Only capture when there is actually something to attribute, and
        # take the row geometry that matches the capture.
        image = None
        if can_capture and any(row.kind == "message" for row in rows):
            image, rows = _capture_aligned(msg_list, origin, size)
            if not rows:
                break
        scale = (image.width / size[0]) if image is not None and size[0] else 1.0

        names: dict[int, str] = {}
        if sender_names and image is not None:
            names = read_sender_names(origin, size, rows)

        visible: list[ChatMessage] = []
        for index, row in enumerate(rows):
            sender, box = classify_row_sender(image, origin, scale, row)
            if row.kind != "message":
                sender = "UNKNOWN"

            image_path = None
            if save_media and image is not None and row.media in VISUAL_MEDIA:
                media_index += 1
                image_path = _save_media(row, origin, box, media_index)

            # WeChat draws no name above your own bubbles, so anything OCR
            # found in that band belongs to a neighbouring row. And a name
            # that just repeats the message text is bubble bleed, not a
            # name — 1:1 chats have no name line at all.
            sender_name = names.get(index)
            if sender == "ME" or (
                sender_name and sender_name[:24] == row.text[:24]
            ):
                sender_name = None

            visible.append(
                ChatMessage(
                    sender=sender,
                    text=row.text,
                    kind=row.kind,
                    media=row.media,
                    image_path=image_path,
                    sender_name=sender_name,
                )
            )

        before = len(messages)
        messages = _merge_older(messages, visible)
        if len(messages) == before:
            # _wait_for_rows already polls for up to SCROLL_SETTLE_TIMEOUT,
            # so two barren rounds is ~0.8s of grace for WeChat to lazily
            # load older history before we call it the top.
            no_new += 1
            if no_new >= 2:
                break
        else:
            no_new = 0

        if len(messages) >= last_n:
            break

        scrolls += 1
        if max_scrolls is not None and scrolls >= max_scrolls:
            break

        fingerprint = _rows_fingerprint(rows)
        post_scroll_pixels(center, int(max(1.0, size[1] * MESSAGE_SCROLL_FRACTION)))
        # A barren round is exactly when WeChat may be lazily loading older
        # history, so wait longer there — and only there. At a flat 0.4s
        # this silently returned 25 messages where 40 existed.
        rows = _wait_for_rows(
            msg_list, fingerprint, SCROLL_SETTLE_TIMEOUT * (1 + no_new)
        )

    if len(messages) > last_n:
        messages = messages[-last_n:]
    elif no_new >= 2:
        # We stopped because the view stopped yielding rows, not because
        # we had enough. WeChat loads older history asynchronously and its
        # timing varies run to run, so this may be short of what exists.
        logger.warning(
            "Reached the top of the loaded history with %d of %d requested "
            "entries; older messages may not have loaded yet. If an expected "
            "message is missing, fetch again with a larger last_n.",
            len(messages),
            last_n,
        )

    logger.info(
        "Fetched %d entries from current chat (last_n=%d, scrolls=%d, captures=%s)",
        len(messages),
        last_n,
        scrolls,
        "on" if can_capture else "off",
    )
    return messages
