from __future__ import annotations

import argparse
import logging
from typing import Any

try:
    # mcp >= 2.0 renamed FastMCP to MCPServer and moved it out of
    # mcp.server.fastmcp, which no longer exists. The tool() decorator and
    # run() signatures are identical, so either class works unchanged below.
    from mcp.server.mcpserver import MCPServer as _Server
except ImportError:  # mcp < 2.0
    from mcp.server.fastmcp import FastMCP as _Server

from .logging_config import logger
from .add_contact_by_wechat_id_utils import (
    add_contact_by_wechat_id as ax_add_contact_by_wechat_id,
)
from .fetch_messages_by_chat_utils import ChatMessage, fetch_recent_messages
from .publish_moment_utils import publish_moment_without_media as ax_publish_moment
from .reply_to_messages_by_chat_utils import send_message
from .wechat_accessibility import (
    get_current_chat_name,
    list_sidebar_chats,
    open_chat_for_contact,
)


mcp = _Server("WeChat Helper MCP Server")


@mcp.tool()
def list_chats() -> list[dict[str, Any]]:
    """
    List every chat in the WeChat sidebar without opening any of them.

    Returns one entry per chat with:
    - `name`: the chat name, exactly as it must be passed to the other tools
    - `preview`: the last message, prefixed with its sender in group chats
    - `timestamp`: when that message arrived ("15:03", "Yesterday 22:28",
      "07/22")

    Use this first when syncing several chats. Comparing `preview` against
    what you recorded last time shows which chats actually have new
    messages, so only those need `fetch_messages_by_chat` — far cheaper
    than opening every chat to discover most are unchanged. It is also how
    to find new chats, and the authoritative source for exact chat names.
    """
    try:
        chats = list_sidebar_chats()
        logger.info("Tool list_chats returning %d chats", len(chats))
        return chats
    except Exception as exc:
        logger.exception("Error in list_chats: %s", exc)
        return [{"error": str(exc)}]


@mcp.tool()
def fetch_messages_by_chat(
    chat_name: str,
    last_n: int = 50,
    sender_names: bool = False,
    save_media: bool = True,
) -> list[dict[str, Any]]:
    """
    Fetch recent messages for a specific chat (contact or group).

    The chat is located using the left sidebar session list only; the
    global search box is never used. This will:
    - Look for the chat among the sidebar rows currently rendered
    - If not there, scroll the sidebar up to the top and then down to the
      bottom, re-reading the rows at each step
    - Click the matching row to open the chat
    - Once the chat is open, retrieve recent messages from that chat

    If no sidebar row matches, no chat is opened and the tool returns the
    sidebar chat names it saw as `candidates.sidebar_chats`, so a more
    specific name can be chosen. Only chats with an existing conversation
    appear in the sidebar.

    Each returned entry has:
    - `kind`: "message" (someone sent it), "timestamp" (a date separator)
      or "system" (a notice such as "You've added X.")
    - `sender`: "ME", "OTHER", or "UNKNOWN"
    - `media`: "image", "video", "file", ... for attachments
    - `image_path`: PNG of an image/video/sticker attachment, so its
      contents can actually be looked at. Text messages are never
      written to disk. Pass save_media=False to disable entirely.
    - `sender_name`: the group-chat display name of the sender. Off by
      default because reading it requires text recognition, which roughly
      triples the time; pass sender_names=True when you need to know who
      said what in a group.
    """
    try:
        logger.info("Tool fetch_messages_by_chat called for chat=%s", chat_name)
        current_chat = get_current_chat_name()
        same_chat = current_chat == chat_name if current_chat is not None else False
        logger.info(
            "Current chat title=%r, target=%r, same_chat=%s",
            current_chat,
            chat_name,
            same_chat,
        )
        if not same_chat:
            open_result = open_chat_for_contact(chat_name)
            if isinstance(open_result, dict) and open_result.get("error"):
                # No exact match; surface candidates instead of forcing a chat.
                logger.info(
                    "open_chat_for_contact returned candidates for chat=%s; "
                    "skipping message fetch",
                    chat_name,
                )
                enriched = dict(open_result)
                enriched.setdefault("tool", "fetch_messages_by_chat")
                return [enriched]

        messages: list[ChatMessage] = fetch_recent_messages(
            last_n=last_n,
            sender_names=sender_names,
            save_media=save_media,
        )
        result = [msg.to_dict() for msg in messages]
        logger.info("Returning %d messages for chat=%s", len(result), chat_name)
        return result
    except Exception as exc:
        logger.exception(
            "Error in fetch_messages_by_chat for chat=%s: %s",
            chat_name,
            exc,
        )
        return [
            {
                "error": str(exc),
                "chat_name": chat_name,
            }
        ]


@mcp.tool()
def reply_to_messages_by_chat(
    chat_name: str,
    reply_message: str | None = None,
) -> dict[str, Any]:
    """
    Optionally send a reply to a chat (contact or group).

    This tool is designed to be driven by the LLM using this MCP:
    - Call fetch_messages_by_chat first to inspect conversation history.
    - Have the LLM compose a reply string.
    - Call this tool with that reply string to send it.

    If reply_message is None or empty, no message is sent; the tool still
    ensures the chat is open.

    The chat is located using the left sidebar session list only (scrolling
    it up and down as needed); the global search box is never used. If no
    sidebar row matches, nothing is sent and the sidebar chat names are
    returned as `candidates.sidebar_chats`.
    """
    logger.info(
        "Tool reply_to_messages_by_chat called for chat=%s (has_reply=%s)",
        chat_name,
        bool(reply_message),
    )
    try:
        current_chat = get_current_chat_name()
        same_chat = current_chat == chat_name if current_chat is not None else False
        logger.info(
            "Current chat title=%r, target=%r, same_chat=%s",
            current_chat,
            chat_name,
            same_chat,
        )
        if not same_chat:
            open_result = open_chat_for_contact(chat_name)
            if isinstance(open_result, dict) and open_result.get("error"):
                logger.info(
                    "open_chat_for_contact returned candidates for chat=%s; "
                    "skipping reply send",
                    chat_name,
                )
                enriched: dict[str, Any] = {
                    "error": open_result.get("error"),
                    "chat_name": chat_name,
                    "candidates": open_result.get("candidates", {}),
                    "reply_message": reply_message,
                    "sent": False,
                    "tool": "reply_to_messages_by_chat",
                }
                return enriched

        sent = False
        if reply_message is not None and reply_message.strip():
            send_message(reply_message)
            sent = True
            logger.info(
                "Reply sent to chat=%s; message length=%d",
                chat_name,
                len(reply_message),
            )

        return {
            "chat_name": chat_name,
            "reply_message": reply_message,
            "sent": sent,
        }
    except Exception as exc:
        logger.exception(
            "Error in reply_to_messages_by_chat for chat=%s: %s",
            chat_name,
            exc,
        )
        return {
            "error": str(exc),
            "chat_name": chat_name,
        }


@mcp.tool()
def add_contact_by_wechat_id(
    wechat_id: str,
    friending_msg: str | None = None,
    remark: str | None = None,
    tags: str | None = None,
    privacy: str | None = None,
    hide_my_posts: bool = False,
    hide_their_posts: bool = False,
) -> dict[str, Any]:
    """
    Add a new contact using a WeChat ID.

    This tool automates the WeChat flow:
    - Type the given WeChat ID into the global search box.
    - Click the "Search WeChat ID" card under the "More" section.
    - In the "Add Contacts" window, click "Add to Contacts".
    - In the "Send Friend Request" window, optionally customize the
      friending message, remark, and privacy options, then confirm.

    The `privacy` argument controls the "Privacy" section of the
    friend-request window:
    - "all" (default) selects "Chats, Moments, WeRun, etc." and applies
      the `hide_my_posts` / `hide_their_posts` flags.
    - "chats_only" selects "Chats Only" and ignores the hide flags.
    """
    logger.info(
        "Tool add_contact_by_wechat_id called for ID=%s (privacy=%r, hide_my_posts=%s, hide_their_posts=%s)",
        wechat_id,
        privacy,
        hide_my_posts,
        hide_their_posts,
    )
    try:
        result = ax_add_contact_by_wechat_id(
            wechat_id=wechat_id,
            friending_msg=friending_msg,
            remark=remark,
            tags=tags,
            privacy=privacy,
            hide_my_posts=hide_my_posts,
            hide_their_posts=hide_their_posts,
        )
        return result
    except Exception as exc:
        logger.exception(
            "Error in add_contact_by_wechat_id for ID=%s: %s",
            wechat_id,
            exc,
        )
        return {
            "error": str(exc),
            "wechat_id": wechat_id,
        }


@mcp.tool()
def publish_moment_without_media(
    content: str,
    publish: bool = True,
) -> dict[str, Any]:
    """
    Publish a Moments post containing only text (no media).

    This will:
    - Open the main WeChat window and click the "Moments" button.
    - Long-press the "Post" button in the Moments window to open the
      composer sheet.
    - Fill the text entry area with the provided content.
    - If `publish` is True (default), click the "Post" button in the
      sheet to publish the moment; if False, leave the composer open
      without sending.
    """
    logger.info(
        "Tool publish_moment_without_media called (content_length=%d, publish=%s)",
        len(content) if isinstance(content, str) else -1,
        publish,
    )
    try:
        result = ax_publish_moment(content=content, publish=publish)
        return result
    except Exception as exc:
        logger.exception("Error in publish_moment_without_media: %s", exc)
        return {
            "error": str(exc),
            "content": content,
        }


def main() -> None:
    """
    Entry point for the WeChat MCP server.
    """
    parser = argparse.ArgumentParser(description="WeChat Helper MCP Server")
    parser.add_argument(
        "--mcp-debug",
        action="store_true",
        help="Enable detailed MCP protocol debugging logs",
    )
    parser.add_argument(
        "--transport",
        choices=["stdio", "streamable-http", "sse"],
        default="stdio",
        help="Transport protocol to use (default: stdio)",
    )

    args = parser.parse_args()

    if args.mcp_debug:
        logging.getLogger("mcp").setLevel(logging.DEBUG)
        logging.getLogger("anyio").setLevel(logging.DEBUG)
        logging.getLogger("httpx").setLevel(logging.DEBUG)
        logger.setLevel(logging.DEBUG)

        debug_formatter = logging.Formatter(
            "%(asctime)s - %(name)s - %(levelname)s - "
            "%(funcName)s:%(lineno)d - %(message)s"
        )
        for handler in logging.getLogger().handlers:
            handler.setFormatter(debug_formatter)

    logger.info("Starting WeChat Helper MCP Server")
    logger.info("Transport: %s", args.transport)
    logger.info("MCP Debug mode: %s", args.mcp_debug)

    if args.transport == "stdio":
        mcp.run()
    elif args.transport == "streamable-http":
        mcp.run(transport="streamable-http")
    elif args.transport == "sse":
        mcp.run(transport="sse")


if __name__ == "__main__":
    main()
