from __future__ import annotations

import re
import time
from dataclasses import dataclass
from typing import Any, Callable

import AppKit
from ApplicationServices import (
    AXUIElementCreateApplication,
    AXUIElementCopyAttributeValue,
    AXUIElementCopyMultipleAttributeValues,
    AXUIElementPerformAction,
    AXUIElementSetAttributeValue,
    AXValueGetType,
    AXValueGetValue,
    kAXChildrenAttribute,
    kAXIdentifierAttribute,
    kAXListRole,
    kAXParentAttribute,
    kAXPositionAttribute,
    kAXRaiseAction,
    kAXRoleAttribute,
    kAXScrollAreaRole,
    kAXSizeAttribute,
    kAXStaticTextRole,
    kAXTextAreaRole,
    kAXTitleAttribute,
    kAXValueAttribute,
    kAXValueCGPointType,
    kAXValueCGSizeType,
    kAXWindowRole,
)
from Quartz import (
    CGEventCreateKeyboardEvent,
    CGEventCreateMouseEvent,
    CGEventCreateScrollWheelEvent,
    CGEventPost,
    CGEventSetFlags,
    CGEventSetLocation,
    CGPoint,
    kCGEventFlagMaskCommand,
    kCGEventLeftMouseDown,
    kCGEventLeftMouseUp,
    kCGHIDEventTap,
    kCGScrollEventUnitLine,
    kCGScrollEventUnitPixel,
)

from .logging_config import logger


def ax_get(element, attribute):
    err, value = AXUIElementCopyAttributeValue(element, attribute, None)
    if err != 0:
        return None
    return value


# WeChat's AX tree is under a dozen levels deep, but it can report
# pathologically deep (or cyclic) child chains while views are being torn
# down, which would otherwise blow Python's stack.
MAX_AX_DEPTH = 40

# How long to let WeChat settle after bringing it to the front.
WECHAT_ACTIVATION_SETTLE = 0.35

# The conversation pane's AX list, used to tell when a chat has opened.
CHAT_MESSAGE_LIST_IDENTIFIER = "chat_message_list"


def wait_for_conversation(ax_app, timeout: float = 2.5) -> bool:
    """
    Wait until a conversation pane exists, i.e. a chat is actually open.

    Clicking a sidebar row returns immediately, but WeChat takes a moment
    to build the message list; polling for it beats sleeping a fixed
    interval on both speed and reliability.
    """

    def is_message_list(el, role, title, identifier):
        return role == kAXListRole and identifier == CHAT_MESSAGE_LIST_IDENTIFIER

    deadline = time.time() + timeout
    while time.time() < deadline:
        if dfs(ax_app, is_message_list) is not None:
            return True
        time.sleep(0.05)
    return False


def dfs(
    element,
    predicate: Callable[[Any, Any, Any, Any], bool],
    depth: int = 0,
):
    if element is None or depth > MAX_AX_DEPTH:
        return None

    role = ax_get(element, kAXRoleAttribute)
    title = ax_get(element, kAXTitleAttribute)
    identifier = ax_get(element, kAXIdentifierAttribute)

    if predicate(element, role, title, identifier):
        return element

    children = ax_get(element, kAXChildrenAttribute) or []
    for child in children:
        found = dfs(child, predicate, depth + 1)
        if found is not None:
            return found
    return None


def get_wechat_ax_app() -> Any:
    """
    Get the AX UI element representing the WeChat application and bring
    it to the foreground.
    """
    bundle_id = "com.tencent.xinWeChat"
    apps = AppKit.NSRunningApplication.runningApplicationsWithBundleIdentifier_(
        bundle_id
    )
    if not apps:
        raise RuntimeError("WeChat is not running")

    app = apps[0]
    was_active = bool(app.isActive())
    app.activateWithOptions_(AppKit.NSApplicationActivateIgnoringOtherApps)
    if not was_active:
        # Reading or clicking the AX tree while WeChat is still coming to
        # the front sees views mid-rebuild: rows are missing, clicks land
        # on nothing, and the child chain can briefly look unbounded.
        time.sleep(WECHAT_ACTIVATION_SETTLE)
    logger.info(
        "Activated WeChat (bundle_id=%s, pid=%s, was_active=%s)",
        bundle_id,
        app.processIdentifier(),
        was_active,
    )
    return AXUIElementCreateApplication(app.processIdentifier())


def _find_window_by_title(ax_app: Any, title: str):
    """
    Locate a top-level WeChat window with the given title.
    """

    def is_window(el, role, current_title, identifier):
        return (
            role == kAXWindowRole
            and isinstance(current_title, str)
            and current_title == title
        )

    return dfs(ax_app, is_window)


def _wait_for_window(ax_app: Any, title: str, timeout: float = 5.0):
    """
    Wait for a window with the given title to appear, returning the AX
    element or None if the timeout expires.
    """
    end = time.time() + timeout
    while time.time() < end:
        window = _find_window_by_title(ax_app, title)
        if window is not None:
            logger.info("Found window %r", title)
            return window
        time.sleep(0.1)
    logger.warning("Timed out waiting for window %r", title)
    return None


def _normalize_chat_title(name: str) -> str:
    """
    Normalize a WeChat chat title.

    In particular, strip a trailing "(<digits>)" suffix that WeChat
    appends for group chats to indicate member count, e.g.:
    "My Group(23)" -> "My Group".
    """
    name = name.strip()
    # Remove trailing "(number)" if present.
    name = re.sub(r"\(\d+\)$", "", name).strip()
    return name


def get_current_chat_name() -> str | None:
    """
    Return the display name of the currently open chat, if available.
    """
    return current_chat_name(get_wechat_ax_app())


def current_chat_name(ax_app) -> str | None:
    """As get_current_chat_name, but reusing an existing app element."""

    def is_chat_title(el, role, title, identifier):
        return role == kAXStaticTextRole and identifier == "big_title_line_h_view"

    title_el = dfs(ax_app, is_chat_title)
    if title_el is None:
        logger.warning("Could not locate current chat title element via AX")
        return None

    value = ax_get(title_el, kAXValueAttribute)
    if isinstance(value, str) and value.strip():
        return _normalize_chat_title(value)

    title = ax_get(title_el, kAXTitleAttribute)
    if isinstance(title, str) and title.strip():
        return _normalize_chat_title(title)

    return None


SESSION_ITEM_PREFIX = "session_item_"

# Reading these four attributes in one batched call is ~2.7x cheaper than
# four separate round-trips into WeChat, and this runs for every row on
# every scroll step.
_SESSION_ITEM_ATTRS = [
    kAXRoleAttribute,
    kAXIdentifierAttribute,
    kAXPositionAttribute,
    kAXSizeAttribute,
    kAXTitleAttribute,
]


@dataclass
class SessionItem:
    """A chat row currently rendered in the left sidebar session list."""

    element: Any
    name: str
    x: float
    y: float
    width: float
    height: float
    preview: str = ""
    timestamp: str = ""

    @property
    def center(self) -> tuple[float, float]:
        return self.x + self.width / 2.0, self.y + self.height / 2.0


def _parse_session_title(title: Any) -> tuple[str, str]:
    """
    Pull the last-message preview and its timestamp out of a sidebar row.

    WeChat packs the whole row into AXTitle as
    "<name>\\n<sender>: <preview>\\n<timestamp>\\n", which is enough to tell
    whether a chat has moved on without opening it.
    """
    if not isinstance(title, str):
        return "", ""
    lines = [line.strip() for line in title.split("\n")]
    lines = [line for line in lines if line]
    if len(lines) < 2:
        return "", ""
    # First line is the display name, last is the timestamp, rest is preview.
    return " ".join(lines[1:-1]), lines[-1]


def _read_session_item(element) -> SessionItem | None:
    """
    Read an element as a sidebar chat row, or return None if it is not one.

    All four attributes are fetched in a single batched call.
    """
    err, values = AXUIElementCopyMultipleAttributeValues(
        element, _SESSION_ITEM_ATTRS, 0, None
    )
    if err != 0 or values is None or len(values) < 5:
        return None

    role, identifier, pos_ref, size_ref, title = values[:5]
    if role != kAXStaticTextRole:
        return None
    if not isinstance(identifier, str) or not identifier.startswith(
        SESSION_ITEM_PREFIX
    ):
        return None

    name = identifier[len(SESSION_ITEM_PREFIX) :]
    if not name:
        return None

    point = axvalue_to_point(pos_ref)
    size = axvalue_to_size(size_ref)
    if point is None or size is None:
        return None

    preview, timestamp = _parse_session_title(title)
    return SessionItem(
        element=element,
        name=name,
        x=point[0],
        y=point[1],
        width=size[0],
        height=size[1],
        preview=preview,
        timestamp=timestamp,
    )


def collect_session_items(ax_app) -> list[SessionItem]:
    """
    Collect the chat rows currently rendered in the left sidebar session
    list, together with their on-screen geometry.

    WeChat recycles sidebar rows, so only the rows near the visible
    viewport exist in the AX tree at any moment. Callers that need a chat
    further down (or up) the list must scroll and collect again.

    `ax_app` may be the application element or, to keep repeated reads
    cheap while scrolling, the sidebar list container itself.
    """
    items: list[SessionItem] = []
    # Keyed by position, not name: WeChat allows two different chats to
    # carry the same display name, and collapsing them by name silently
    # loses one of them.
    seen_rows: set[tuple[str, int]] = set()

    def add(element) -> None:
        item = _read_session_item(element)
        if item is None:
            return
        key = (item.name, int(item.y))
        if key in seen_rows:
            return
        seen_rows.add(key)
        items.append(item)

    # Fast path: the session rows are direct children of the session list
    # container, so there is no need to recurse into each row's subtree.
    for child in ax_get(ax_app, kAXChildrenAttribute) or []:
        add(child)

    if not items:
        # Fallback for when we were handed the application element (or a
        # WeChat build that nests the rows differently).
        def walk(element, depth: int = 0):
            if depth > 14:
                return
            add(element)
            for child in ax_get(element, kAXChildrenAttribute) or []:
                walk(child, depth + 1)

        walk(ax_app)

    items.sort(key=lambda item: item.y)
    return items


def collect_chat_elements(ax_app) -> dict[str, Any]:
    """
    Collect chat elements from the left session list keyed by display name.
    """
    results = {item.name: item.element for item in collect_session_items(ax_app)}
    logger.info("Collected %d chat elements from session list", len(results))
    return results


def _match_session_item(items: list[SessionItem], chat_name: str) -> SessionItem | None:
    """
    Find the sidebar row matching the requested chat name.

    Matching is tried exact first, then case-insensitively, then against
    the normalized title (which drops the "(23)" member-count suffix that
    WeChat appends to group chats).
    """
    target = chat_name.strip()

    def pick(matches: list[SessionItem]) -> SessionItem | None:
        if not matches:
            return None
        if len(matches) > 1:
            # WeChat permits duplicate display names. The sidebar is sorted
            # by recency, so the topmost row is the most recently active
            # chat of that name — but say so, because the other one is a
            # different conversation.
            logger.warning(
                "%d sidebar chats are named %r; using the most recent one",
                len(matches),
                target,
            )
        return min(matches, key=lambda item: item.y)

    exact = pick([item for item in items if item.name == target])
    if exact is not None:
        return exact

    lowered = target.lower()
    insensitive = pick([item for item in items if item.name.lower() == lowered])
    if insensitive is not None:
        return insensitive

    normalized = _normalize_chat_title(target).lower()
    if not normalized:
        return None
    return pick(
        [
            item
            for item in items
            if _normalize_chat_title(item.name).lower() == normalized
        ]
    )


def find_chat_element_by_name(ax_app, chat_name: str):
    """
    Find a chat element whose name matches the given chat name in the
    rows the sidebar currently has rendered (no scrolling).
    """
    match = _match_session_item(collect_session_items(ax_app), chat_name)
    return match.element if match is not None else None


def get_sidebar_list(ax_app):
    """
    Return the AX container (list or scroll area) that holds the sidebar
    session rows.

    WeChat exposes it as an AXList with the identifier "session_list";
    looking that up directly short-circuits the search. Older or newer
    builds fall back to walking up from a rendered row.

    Returns None when the sidebar cannot be located at all.
    """
    def is_session_list(el, role, title, identifier):
        return role == kAXListRole and identifier == SIDEBAR_LIST_IDENTIFIER

    container = dfs(ax_app, is_session_list)
    if container is not None:
        return container

    items = collect_session_items(ax_app)
    if not items:
        return None

    element = items[0].element
    for _ in range(12):
        parent = ax_get(element, kAXParentAttribute)
        if parent is None:
            return None
        role = ax_get(parent, kAXRoleAttribute)
        size = axvalue_to_size(ax_get(parent, kAXSizeAttribute))
        if role in (kAXListRole, kAXScrollAreaRole) and size is not None:
            # The container must be tall enough to actually be the list
            # viewport rather than a single row's wrapper.
            if size[1] >= max(200.0, items[0].height * 3):
                return parent
        element = parent
    return None


def get_sidebar_bounds(ax_app, container=None) -> tuple[float, float, float, float] | None:
    """
    Return the (left, top, right, bottom) screen rect of the sidebar
    session list viewport.

    Pass `container` to reuse an already-resolved session list. Falls back
    to the bounding box of the currently rendered rows when the list
    container cannot be located.
    """
    if container is None:
        container = get_sidebar_list(ax_app)
    if container is not None:
        origin = axvalue_to_point(ax_get(container, kAXPositionAttribute))
        size = axvalue_to_size(ax_get(container, kAXSizeAttribute))
        if origin is not None and size is not None:
            return origin[0], origin[1], origin[0] + size[0], origin[1] + size[1]

    items = collect_session_items(ax_app)
    if not items:
        return None
    left = min(item.x for item in items)
    top = min(item.y for item in items)
    right = max(item.x + item.width for item in items)
    bottom = max(item.y + item.height for item in items)
    return left, top, right, bottom


def get_sidebar_scroll_point(ax_app, container=None) -> tuple[float, float] | None:
    """
    Return the screen point that scroll-wheel events should target in
    order to scroll the sidebar session list.
    """
    bounds = get_sidebar_bounds(ax_app, container)
    if bounds is None:
        return None
    left, top, right, bottom = bounds
    return (left + right) / 2.0, (top + bottom) / 2.0


# Rows of overlap kept between consecutive reads, so a step can never jump
# clean over an unread row.
SIDEBAR_OVERLAP_ROWS = 4
SIDEBAR_MIN_STEP_PIXELS = 60
SIDEBAR_STEP_PIXELS = 400  # fallback when the row geometry is unknown
SIDEBAR_JUMP_PIXELS = 20000  # comfortably past the end of any session list

# How many identical reads in a row mean we have really reached the end.
# Scrolling towards the bottom needs patience because WeChat appends older
# chats lazily; the top of the list never grows, so it can bail out fast.
SIDEBAR_STABLE_READS_DOWN = 4
SIDEBAR_STABLE_READS_UP = 2
SIDEBAR_SETTLE_SECONDS = 0.35

# Identifier of the sidebar session list container in WeChat 4.x.
SIDEBAR_LIST_IDENTIFIER = "session_list"


def _sidebar_fingerprint(items: list[SessionItem]) -> str:
    return "|".join(item.name for item in items)


def _step_pixels_for(items: list[SessionItem]) -> int:
    """
    Size a scroll step at nearly one screenful of rows.

    The sidebar renders ~14 rows at a time, so advancing a row at a time
    re-reads almost the same rows over and over. Step by a screenful minus
    an overlap margin instead.
    """
    if len(items) <= SIDEBAR_OVERLAP_ROWS:
        return SIDEBAR_STEP_PIXELS

    row_height = max(1.0, min(item.height for item in items))
    step_rows = max(1, len(items) - SIDEBAR_OVERLAP_ROWS)
    return max(SIDEBAR_MIN_STEP_PIXELS, int(step_rows * row_height))


def _scan_sidebar_while_scrolling(
    root,
    point: tuple[float, float],
    delta_pixels: int,
    chat_name: str,
    seen: list[str],
    max_steps: int,
) -> SessionItem | None:
    """
    Repeatedly collect the rendered sidebar rows and scroll by
    `delta_pixels`, until the requested chat is found or the list stops
    producing new rows (i.e. we hit the top or bottom).

    Positive `delta_pixels` scrolls towards the top of the list, negative
    towards the bottom. `root` is the sidebar list container when it could
    be located, otherwise the application element.
    """
    going_down = delta_pixels < 0
    stable_limit = SIDEBAR_STABLE_READS_DOWN if going_down else SIDEBAR_STABLE_READS_UP
    direction = -1 if going_down else 1

    last_fingerprint: str | None = None
    previous_names: set[str] = set()
    step_pixels = abs(delta_pixels)
    stable = 0

    for _ in range(max_steps):
        items = collect_session_items(root)
        names = {item.name for item in items}
        for item in items:
            if item.name not in seen:
                seen.append(item.name)

        match = _match_session_item(items, chat_name)
        if match is not None:
            return match

        # A step that lands with no rows in common with the previous read
        # may have skipped over rows entirely; back up and go finer.
        if previous_names and names.isdisjoint(previous_names):
            if step_pixels > SIDEBAR_MIN_STEP_PIXELS:
                step_pixels = max(SIDEBAR_MIN_STEP_PIXELS, step_pixels // 2)
                logger.debug(
                    "Sidebar step overshot; backing up and reducing to %d px",
                    step_pixels,
                )
                post_scroll_pixels(point, -direction * step_pixels)
                time.sleep(0.12)
                previous_names = set()
                continue

        fingerprint = _sidebar_fingerprint(items)
        if fingerprint == last_fingerprint:
            stable += 1
            if stable >= stable_limit:
                return None
            if going_down:
                # Rows stopped changing, but WeChat may still be appending
                # older chats; give it a moment before calling this the end.
                time.sleep(SIDEBAR_SETTLE_SECONDS)
        else:
            last_fingerprint = fingerprint
            stable = 0
            step_pixels = max(step_pixels, _step_pixels_for(items))

        previous_names = names
        post_scroll_pixels(point, direction * step_pixels)
        time.sleep(0.12)

    return None


def _dismiss_search_popover(ax_app) -> None:
    """
    Dismiss an open search popover so the sidebar shows the session list.

    Only sends Escape when a popover is actually present: in WeChat that
    key also closes the open conversation, and a stray Escape can be
    delivered *after* the subsequent click, silently undoing it.
    """

    def is_search_list(el, role, title, identifier):
        return role == kAXListRole and identifier == "search_list"

    if dfs(ax_app, is_search_list) is None:
        return

    logger.info("Dismissing WeChat search popover")
    send_key_with_modifiers(53, 0)  # Escape
    time.sleep(0.25)


def _is_item_clickable(item: SessionItem, bounds: tuple[float, float, float, float] | None) -> bool:
    """
    Whether the row's center currently sits inside the visible sidebar
    viewport, so that clicking it will actually land on the row.
    """
    if bounds is None:
        return True
    left, top, right, bottom = bounds
    cx, cy = item.center
    return left <= cx <= right and top <= cy <= bottom


def _bring_item_into_view(
    ax_app,
    item: SessionItem,
    chat_name: str,
    point: tuple[float, float],
    container=None,
    attempts: int = 4,
) -> SessionItem | None:
    """
    Scroll the sidebar so the matched row sits fully inside the viewport,
    so that click_element_center lands on it.

    Because pixel-unit scrolling moves the list by exactly the requested
    amount, the required delta can be computed directly rather than
    nudged towards.

    Returns None if the row could not be placed inside the viewport, in
    which case it must NOT be clicked: its coordinates may be off-screen
    entirely and the synthetic click would land on whatever is there.
    """
    root = container if container is not None else ax_app

    for _ in range(attempts):
        bounds = get_sidebar_bounds(ax_app, container)
        if bounds is None:
            return item
        if _is_item_clickable(item, bounds):
            return item

        _, top, _, bottom = bounds
        _, cy = item.center
        margin = item.height
        desired_cy = min(max(cy, top + margin), bottom - margin)
        delta = int(desired_cy - cy)
        if delta == 0:
            return item

        post_scroll_pixels(point, delta)
        time.sleep(0.12)

        item = _match_session_item(collect_session_items(root), chat_name)
        if item is None:
            logger.warning(
                "Row for %r disappeared while scrolling it into view", chat_name
            )
            return None

    bounds = get_sidebar_bounds(ax_app, container)
    if bounds is not None and not _is_item_clickable(item, bounds):
        return None
    return item


def stable_session_items(root, timeout: float = 0.6) -> list[SessionItem]:
    """
    Read the sidebar rows once they have stopped changing.

    Reading a fixed interval after a scroll catches WeChat mid-recycle:
    rows briefly carry the previous chat's preview text, or are missing
    entirely. Requiring two consecutive identical reads costs a few
    milliseconds and removes that whole class of wrong answer.
    """
    previous = collect_session_items(root)
    fingerprint = _sidebar_fingerprint(previous)
    deadline = time.time() + timeout

    while time.time() < deadline:
        time.sleep(0.05)
        current = collect_session_items(root)
        current_fingerprint = _sidebar_fingerprint(current)
        if current_fingerprint == fingerprint:
            return current
        previous, fingerprint = current, current_fingerprint

    return previous


def list_sidebar_chats(ax_app=None, max_steps: int = 60) -> list[dict[str, str]]:
    """
    Read every chat in the sidebar — name, last-message preview and
    timestamp — without opening a single conversation.

    WeChat puts all three in each row's AXTitle, so a caller can tell
    which chats have moved on since last time and open only those. That
    turns a full roster sync from one conversation-open per chat into a
    single sidebar read.
    """
    if ax_app is None:
        ax_app = get_wechat_ax_app()

    container = get_sidebar_list(ax_app)
    root = container if container is not None else ax_app
    point = get_sidebar_scroll_point(ax_app, container)

    # Keyed by the whole row, so two chats sharing a display name both
    # survive instead of one overwriting the other.
    ordered: list[tuple[str, str, str]] = []
    seen: dict[tuple[str, str, str], dict[str, str]] = {}

    def absorb() -> list[SessionItem]:
        items = stable_session_items(root)
        for item in items:
            key = (item.name, item.timestamp, item.preview)
            if key in seen:
                continue
            ordered.append(key)
            seen[key] = {
                "name": item.name,
                "preview": item.preview,
                "timestamp": item.timestamp,
            }
        return items

    items = absorb()
    if point is None or not items:
        return _flag_duplicate_names([seen[key] for key in ordered])

    # Start at the top, then page down until the rows stop changing.
    post_scroll_pixels(point, SIDEBAR_JUMP_PIXELS)
    time.sleep(0.2)
    items = absorb()

    step = _step_pixels_for(items)
    last_fingerprint: str | None = None
    stable = 0

    for _ in range(max_steps):
        # One read per iteration, and every read is absorbed — reading the
        # tree twice and only recording one of them drops rows that were
        # visible in the other.
        fingerprint = _sidebar_fingerprint(absorb())
        if fingerprint == last_fingerprint:
            stable += 1
            if stable >= SIDEBAR_STABLE_READS_DOWN:
                break
            time.sleep(SIDEBAR_SETTLE_SECONDS)
        else:
            last_fingerprint = fingerprint
            stable = 0

        post_scroll_pixels(point, -step)
        time.sleep(0.12)

    # Leave the sidebar where we found it.
    post_scroll_pixels(point, SIDEBAR_JUMP_PIXELS)
    time.sleep(0.15)

    logger.info("Listed %d sidebar chats", len(ordered))
    return _flag_duplicate_names([seen[key] for key in ordered])


def _flag_duplicate_names(chats: list[dict[str, str]]) -> list[dict[str, str]]:
    """
    Mark chats whose display name is shared with another chat.

    Callers address chats by name, so a shared name is genuinely
    ambiguous — the caller needs to know rather than silently getting
    whichever one sorts first.
    """
    counts: dict[str, int] = {}
    for chat in chats:
        counts[chat["name"]] = counts.get(chat["name"], 0) + 1

    for chat in chats:
        if counts[chat["name"]] > 1:
            chat["duplicate_name"] = True
    return chats


def find_chat_in_sidebar(
    ax_app, chat_name: str, max_steps: int = 120
) -> tuple[SessionItem | None, list[str]]:
    """
    Locate a chat in the left sidebar session list, scrolling the list up
    and then down as needed.

    Returns the matching row (or None) plus the names of every sidebar
    chat seen along the way, so callers can offer candidates.
    """
    seen: list[str] = []

    # Resolve the list container once: re-reading the whole application AX
    # tree costs ~64ms a time, versus ~1ms scoped to the container.
    container = get_sidebar_list(ax_app)
    root = container if container is not None else ax_app

    items = collect_session_items(root)
    for item in items:
        if item.name not in seen:
            seen.append(item.name)

    match = _match_session_item(items, chat_name)
    if match is not None:
        logger.info("Found %r in the sidebar rows already rendered", chat_name)
        return match, seen

    point = get_sidebar_scroll_point(ax_app, container)
    if point is None:
        logger.warning("Could not locate the WeChat sidebar session list")
        return None, seen

    step = _step_pixels_for(items)

    logger.info("Scanning sidebar upwards for %r", chat_name)
    match = _scan_sidebar_while_scrolling(
        root, point, step, chat_name, seen, max_steps
    )
    if match is not None:
        return match, seen

    logger.info("Scanning sidebar downwards for %r", chat_name)
    match = _scan_sidebar_while_scrolling(
        root, point, -step, chat_name, seen, max_steps
    )
    if match is not None:
        return match, seen

    # Leave the sidebar back at the top so the next lookup starts from a
    # predictable position.
    post_scroll_pixels(point, SIDEBAR_JUMP_PIXELS)
    time.sleep(0.15)
    return None, seen


def send_key_with_modifiers(keycode: int, flags: int):
    event_down = CGEventCreateKeyboardEvent(None, keycode, True)
    CGEventSetFlags(event_down, flags)
    event_up = CGEventCreateKeyboardEvent(None, keycode, False)
    CGEventSetFlags(event_up, flags)
    CGEventPost(kCGHIDEventTap, event_down)
    CGEventPost(kCGHIDEventTap, event_up)


def click_element_center(element) -> None:
    """
    Synthesize a left mouse click at the visual center of the element.
    """
    pos_ref = ax_get(element, kAXPositionAttribute)
    size_ref = ax_get(element, kAXSizeAttribute)
    point = axvalue_to_point(pos_ref)
    size = axvalue_to_size(size_ref)
    if point is None or size is None:
        raise RuntimeError("Failed to get bounds for element to click")

    x, y = point
    w, h = size
    cx = x + w / 2.0
    cy = y + h / 2.0

    event_down = CGEventCreateMouseEvent(
        None, kCGEventLeftMouseDown, CGPoint(cx, cy), 0
    )
    event_up = CGEventCreateMouseEvent(None, kCGEventLeftMouseUp, CGPoint(cx, cy), 0)
    CGEventPost(kCGHIDEventTap, event_down)
    CGEventPost(kCGHIDEventTap, event_up)


def long_press_element_center(element, hold_seconds: float = 2.2) -> None:
    """
    Synthesize a long left mouse press at the visual center of the
    given element.
    """
    pos_ref = ax_get(element, kAXPositionAttribute)
    size_ref = ax_get(element, kAXSizeAttribute)
    point = axvalue_to_point(pos_ref)
    size = axvalue_to_size(size_ref)
    if point is None or size is None:
        raise RuntimeError("Failed to get bounds for element to long-press")

    x, y = point
    w, h = size
    cx = x + w / 2.0
    cy = y + h / 2.0

    event_down = CGEventCreateMouseEvent(
        None, kCGEventLeftMouseDown, CGPoint(cx, cy), 0
    )
    CGEventPost(kCGHIDEventTap, event_down)
    try:
        time.sleep(max(0.0, hold_seconds))
    finally:
        event_up = CGEventCreateMouseEvent(
            None, kCGEventLeftMouseUp, CGPoint(cx, cy), 0
        )
        CGEventPost(kCGHIDEventTap, event_up)


def find_search_field(ax_app):
    def is_search(el, role, title, identifier):
        return role == kAXTextAreaRole and title == "Search"

    search = dfs(ax_app, is_search)
    if search is None:
        raise RuntimeError(
            "Could not find WeChat search text field via Accessibility API"
        )
    return search


def focus_and_type_search(ax_app, text: str):
    """
    Focus the WeChat sidebar search field and type the given text using
    Command+A and Command+V
    """
    search = find_search_field(ax_app)

    AXUIElementPerformAction(search, kAXRaiseAction)

    # Clear any existing value via AX (best effort).
    err = AXUIElementSetAttributeValue(search, kAXValueAttribute, "")
    if err != 0:
        logger.debug("Failed to clear search field via AX (err=%s)", err)

    pb = AppKit.NSPasteboard.generalPasteboard()
    pb.clearContents()
    pb.setString_forType_(text, AppKit.NSPasteboardTypeString)

    time.sleep(0.1)

    keycode_a = 0  # US keyboard 'A'
    keycode_v = 9  # US keyboard 'V'
    send_key_with_modifiers(keycode_a, kCGEventFlagMaskCommand)
    time.sleep(0.05)
    send_key_with_modifiers(keycode_v, kCGEventFlagMaskCommand)


def open_chat_for_contact(chat_name: str) -> dict[str, Any] | None:
    """
    Open a chat for a given name (contact or group) using **only** the
    left sidebar session list.

    WeChat's global search is deliberately not used here: its result
    popover is unreliable to drive through the Accessibility API. Instead
    this:
    - Dismisses any leftover search popover so the session list is shown.
    - Looks through the sidebar rows that are currently rendered.
    - If the chat is not among them, scrolls the sidebar up to the top
      and then down to the bottom, re-reading the rows at each step
      (WeChat only exposes rows near the viewport to the AX API).
    - Scrolls the matched row fully into view before clicking it.

    On success returns None. If the chat is not in the sidebar at all, it
    returns a dict of the form:

    {
        "error": "<LLM-friendly message>",
        "chat_name": "<original chat_name>",
        "candidates": {"sidebar_chats": [... up to 40 names ...]},
    }

    Callers can use this to ask the LLM to choose a more specific target.
    """
    logger.info("Opening chat for name: %s", chat_name)
    ax_app = get_wechat_ax_app()

    # Clicking the row of the chat that is already open toggles it shut,
    # so opening has to be idempotent no matter who calls it.
    current = current_chat_name(ax_app)
    if current is not None and _normalize_chat_title(
        current
    ).lower() == _normalize_chat_title(chat_name).lower():
        logger.info("Chat %r is already open; nothing to click", chat_name)
        return None

    _dismiss_search_popover(ax_app)

    item, seen = find_chat_in_sidebar(ax_app, chat_name)
    if item is not None:
        container = get_sidebar_list(ax_app)
        point = get_sidebar_scroll_point(ax_app, container)
        if point is not None:
            item = _bring_item_into_view(
                ax_app, item, chat_name, point, container=container
            )

        if item is not None:
            logger.info("Clicking sidebar row for %r", item.name)
            click_element_center(item.element)
            if not wait_for_conversation(ax_app):
                logger.warning(
                    "Clicked %r but no conversation pane appeared", item.name
                )
            return None

        # Never click a row we could not place inside the sidebar: its
        # coordinates may be off-screen and the click would land elsewhere.
        logger.warning(
            "Found %r in the sidebar but could not scroll it into view", chat_name
        )
        return {
            "error": (
                "Found the chat in the WeChat sidebar but could not scroll its "
                "row fully into view, so it was not clicked. Try again, or "
                "resize the WeChat window."
            ),
            "chat_name": chat_name,
            "candidates": {"sidebar_chats": seen[:40]},
        }

    error_msg = (
        "Could not find a chat with that name in the WeChat sidebar after "
        "scrolling the session list to the top and the bottom. The sidebar "
        "only lists chats with existing conversations, so the chat may not "
        "be open yet, or the name may differ. Returning the sidebar chat "
        "names so a more specific chat can be chosen."
    )
    logger.warning(
        "open_chat_for_contact(%s) found no sidebar match; %d chats seen",
        chat_name,
        len(seen),
    )
    return {
        "error": error_msg,
        "chat_name": chat_name,
        "candidates": {"sidebar_chats": seen[:40]},
    }


def get_search_list(ax_app):
    """
    Return the AX list that contains global search results in the
    left sidebar (identifier: 'search_list').
    """

    def is_search_list(el, role, title, identifier):
        return role == kAXListRole and identifier == "search_list"

    search_list = dfs(ax_app, is_search_list)
    if search_list is None:
        raise RuntimeError(
            "Could not find WeChat search results list via Accessibility API"
        )
    return search_list


@dataclass
class SearchEntry:
    element: Any
    text: str
    y: float


def _collect_search_entries(search_list) -> list[SearchEntry]:
    """
    Collect visible static-text entries from the search results list,
    including section headers, result cards and "View All"/"Collapse"
    rows. Entries are sorted by vertical (Y) position.
    """
    entries: list[SearchEntry] = []

    def walk(el):
        role = ax_get(el, kAXRoleAttribute)
        if role == kAXStaticTextRole:
            title = ax_get(el, kAXTitleAttribute)
            value = ax_get(el, kAXValueAttribute)
            text_obj = title if isinstance(title, str) and title else value
            if isinstance(text_obj, str):
                pos_ref = ax_get(el, kAXPositionAttribute)
                point = axvalue_to_point(pos_ref)
                y = point[1] if point is not None else 0.0
                entries.append(
                    SearchEntry(
                        element=el,
                        text=text_obj.strip(),
                        y=float(y),
                    )
                )

        children = ax_get(el, kAXChildrenAttribute) or []
        for child in children:
            walk(child)

    walk(search_list)
    entries.sort(key=lambda e: e.y)
    return entries


def _build_section_headers(entries: list[SearchEntry]) -> dict[str, float]:
    """
    Map known section titles ("Contacts", "Group Chats", "Chat History", "Official Accounts", "Internet search results", "More")
    to their vertical Y coordinate within the search list.
    """
    headers: dict[str, float] = {}
    for entry in entries:
        if entry.text in (
            "Contacts",
            "Group Chats",
            "Chat History",
            "Official Accounts",
            "Internet search results",
            "More",
        ):
            headers[entry.text] = entry.y
    return headers


def _classify_section(entry: SearchEntry, headers: dict[str, float]) -> str | None:
    """
    Given an entry and the Y positions of section headers, determine which
    section this entry belongs to by picking the last header above it.
    """
    section: str | None = None
    best_y = float("-inf")
    for title, header_y in headers.items():
        if header_y <= entry.y and header_y > best_y:
            section = title
            best_y = header_y
    return section


def _find_exact_match_in_entries(entries: list[SearchEntry], contact_name: str):
    """
    Look for an exact match in the current snapshot of search results.

    Preference order:
    - Exact match under "Contacts"
    - Exact match under "Group Chats"

    Entries classified as "Chat History", "Official Accounts", "Internet search results", or "More" are ignored.
    """
    target = contact_name.strip()
    headers = _build_section_headers(entries)

    contact_element = None
    group_element = None

    for entry in entries:
        if entry.text != target:
            continue
        section = _classify_section(entry, headers)
        if section == "Contacts" and contact_element is None:
            contact_element = entry.element
        elif section == "Group Chats" and group_element is None:
            group_element = entry.element

    if contact_element is not None:
        return contact_element
    if group_element is not None:
        return group_element
    return None


def _summarize_search_candidates(
    entries: list[SearchEntry],
) -> dict[str, list[str]]:
    """
    Summarize candidate names from search entries, grouped by section.

    Returns up to 15 unique names from each of:
    - "Contacts"
    - "Group Chats"

    Entries belonging to "Chat History", "Official Accounts", "Internet search results", or "More" are ignored.
    """
    headers = _build_section_headers(entries)
    contacts: list[str] = []
    group_chats: list[str] = []

    for entry in entries:
        # Skip section headers themselves.
        if entry.text in (
            "Contacts",
            "Group Chats",
            "Chat History",
            "Official Accounts",
            "Internet search results",
            "More",
        ):
            continue

        section = _classify_section(entry, headers)
        if section == "Contacts":
            if entry.text not in contacts:
                contacts.append(entry.text)
        elif section == "Group Chats":
            if entry.text not in group_chats:
                group_chats.append(entry.text)

    return {
        "contacts": contacts[:15],
        "group_chats": group_chats[:15],
    }


def _expand_section_if_needed(search_list, section_title: str) -> None:
    """
    If a "View All(...)" row exists for the given section title
    ("Contacts" or "Group Chats"), click its center to expand that section.
    """
    entries = _collect_search_entries(search_list)
    headers = _build_section_headers(entries)
    if section_title not in headers:
        return

    for entry in entries:
        if not entry.text.startswith("View All"):
            continue
        section = _classify_section(entry, headers)
        if section == section_title:
            logger.info("Expanding %s section via %r", section_title, entry.text)
            click_element_center(entry.element)
            time.sleep(0.3)
            return


def _select_contact_from_search_results(
    ax_app, contact_name: str
) -> tuple[bool, dict[str, list[str]]]:
    """
    Try to open a chat by selecting an exact match from the global
    search results list, preferring Contacts over Group Chats and
    ignoring the Chat History, Official Accounts, "Internet search results", and More sections.
    """
    search_list = get_search_list(ax_app)

    aggregated_contacts: set[str] = set()
    aggregated_groups: set[str] = set()

    def update_candidates(entries: list[SearchEntry]) -> None:
        partial = _summarize_search_candidates(entries)
        aggregated_contacts.update(partial["contacts"])
        aggregated_groups.update(partial["group_chats"])

    # First, inspect the initial compact search popover without scrolling.
    entries = _collect_search_entries(search_list)
    update_candidates(entries)
    element = _find_exact_match_in_entries(entries, contact_name)
    if element is not None:
        logger.info("Found exact match for %s in initial search results", contact_name)
        click_element_center(element)
        return True, {
            "contacts": list(aggregated_contacts)[:15],
            "group_chats": list(aggregated_groups)[:15],
        }

    # No exact match visible yet; expand Contacts and Group Chats if possible.
    _expand_section_if_needed(search_list, "Contacts")
    _expand_section_if_needed(search_list, "Group Chats")

    center = get_list_center(search_list)
    last_bottom_text = None
    stable = 0

    # Scroll through the expanded search list, looking for an
    # exact match under Contacts/Group Chats, while aggregating
    # candidate names from Contacts and Group Chats.
    for _ in range(80):
        entries = _collect_search_entries(search_list)
        update_candidates(entries)

        element = _find_exact_match_in_entries(entries, contact_name)
        if element is not None:
            logger.info(
                "Found exact match for %s while scrolling search results",
                contact_name,
            )
            click_element_center(element)
            return True, {
                "contacts": list(aggregated_contacts)[:15],
                "group_chats": list(aggregated_groups)[:15],
            }

        children = ax_get(search_list, kAXChildrenAttribute) or []
        texts: list[str] = []
        for child in children:
            txt = ax_get(child, kAXValueAttribute) or ax_get(child, kAXTitleAttribute)
            if isinstance(txt, str) and txt.strip():
                texts.append(txt)

        if not texts:
            break

        new_last = texts[-1]
        if new_last == last_bottom_text:
            stable += 1
            if stable >= 3:
                break
        else:
            last_bottom_text = new_last
            stable = 0

        # Negative delta scrolls downwards through the search results list.
        post_scroll(center, -80)
        time.sleep(0.1)

    return False, {
        "contacts": list(aggregated_contacts)[:15],
        "group_chats": list(aggregated_groups)[:15],
    }


def axvalue_to_point(ax_value):
    if ax_value is None or AXValueGetType(ax_value) != kAXValueCGPointType:
        return None
    ok, cg_point = AXValueGetValue(ax_value, kAXValueCGPointType, None)
    if not ok:
        return None
    return float(cg_point.x), float(cg_point.y)


def axvalue_to_size(ax_value):
    if ax_value is None or AXValueGetType(ax_value) != kAXValueCGSizeType:
        return None
    ok, cg_size = AXValueGetValue(ax_value, kAXValueCGSizeType, None)
    if not ok:
        return None
    return float(cg_size.width), float(cg_size.height)


def get_list_center(msg_list):
    """
    Compute the on-screen center point of the messages (or search) list,
    used as the target for scroll-wheel events.
    """
    pos_ref = ax_get(msg_list, kAXPositionAttribute)
    size_ref = ax_get(msg_list, kAXSizeAttribute)
    origin = axvalue_to_point(pos_ref)
    size = axvalue_to_size(size_ref)
    if origin is None or size is None:
        raise RuntimeError("Failed to get bounds for list element")

    x, y = origin
    w, h = size
    return x + w / 2.0, y + h / 2.0


def post_scroll(center, delta_lines: int) -> None:
    """
    Post a scroll-wheel event at the given screen position.

    On a standard macOS configuration:
    - Positive delta_lines scrolls towards older content (upwards in history).
    - Negative delta_lines scrolls towards newer content (downwards in history).
    """
    cx, cy = center
    event = CGEventCreateScrollWheelEvent(None, kCGScrollEventUnitLine, 1, delta_lines)
    CGEventSetLocation(event, CGPoint(cx, cy))
    CGEventPost(kCGHIDEventTap, event)


def post_scroll_pixels(center, delta_pixels: int) -> None:
    """
    Post a pixel-unit scroll-wheel event at the given screen position.

    WeChat clamps *line*-unit scroll events to a single row however large
    the delta is (3 lines and 120 lines both move exactly one row), and
    coalesces events posted back to back. Pixel units are honoured
    exactly, so a single event can move a whole page.

    The sign convention matches post_scroll: positive scrolls towards the
    top of the list, negative towards the bottom. A row's Y coordinate
    shifts by exactly `delta_pixels`.
    """
    cx, cy = center
    event = CGEventCreateScrollWheelEvent(
        None, kCGScrollEventUnitPixel, 1, int(delta_pixels)
    )
    CGEventSetLocation(event, CGPoint(cx, cy))
    CGEventPost(kCGHIDEventTap, event)
